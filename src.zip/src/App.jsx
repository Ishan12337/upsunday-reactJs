// import Navbar from "./components/Navbar";
// import Hero from "./components/Hero";
// import SelectedWork from "./components/SelectedWork";
// import Clients from "./components/Clients";
// import Services from "./components/Services";
// import ByTheNumber from "./components/ByTheNumber";
// import Recognition from "./components/Recognition";
// import Testimonials from "./components/Testimonials";
// import Blog from "./components/Blog";
// import Contact from "./components/Contact";
// import Footer from "./components/Footer";

// function App() {
//   return (
//     <>
//       <Navbar />
//       <main>
//         <Hero />
//         <SelectedWork />
//         <Clients />
//         <Services />
//         <ByTheNumber />
//         <Recognition />
//         <Testimonials />
//         <Blog />
//         <Contact />
//       </main>
//       <Footer />
//     </>
//   );
// }

// export default App;


import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import SelectedWork from "./components/SelectedWork";
// import Services from "./components/Services";
// import ByTheNumber from "./components/ByTheNumber";
// import Recognition from "./components/Recognition";
// import Testimonials from "./components/Testimonials";
// import Blog from "./components/Blog";
// import ContactCTA from "./components/ContactCTA";
// import Footer from "./components/Footer";

function App() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
         <SelectedWork />
        {/*<Services />
        <ByTheNumber />
        <Recognition />
        <Testimonials />
        <Blog />
        <ContactCTA /> */}
      </main>
      {/* <Footer /> */}
    </>
  );
}

export default App;
