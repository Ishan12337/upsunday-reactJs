//import { useEffect, useRef } from "react";
import "./styling/Hero.css";

import heroWallpaper from "../assets/hero/Hero-wallpaper.jpg";

const Hero = () => {
  // const heroRef = useRef(null);

  // useEffect(() => {
  //   const hero = heroRef.current;

  //   if (!hero) return;

  //   const handleMouseMove = (event) => {
  //     const rect = hero.getBoundingClientRect();

  //     const x = ((event.clientX - rect.left) / rect.width - 0.5) * 2;
  //     const y = ((event.clientY - rect.top) / rect.height - 0.5) * 2;

  //     hero.style.setProperty("--mouse-x", `${x}`);
  //     hero.style.setProperty("--mouse-y", `${y}`);
  //   };

  //   hero.addEventListener("mousemove", handleMouseMove);

  //   return () => {
  //     hero.removeEventListener("mousemove", handleMouseMove);
  //   };
  // }, []);

  return (
    <section id="home" className="hero-section">
      <div className="hero">
        <div className="hero-background">
          <img
            src={heroWallpaper}
            alt=""
            className="hero-background-image"
          />

          <div className="hero-background-overlay" />
        </div>

        <div className="hero-content">
          <div className="hero-heading-wrap">
            <h1 className="hero-heading">
              <span>Brands &amp;</span>
              <span>Websites</span>
            </h1>
          </div>

          <div className="hero-copy-wrap">
            <p className="hero-copy">
              We design brands and build websites, software and motion for
              businesses ready to grow.
            </p>

            <p className="hero-copy">
              Great work doesn't wait for Monday.
            </p>

            <p className="hero-copy">
              Always UpSunday.
            </p>

            <div className="hero-actions">
              <a href="#work" className="hero-button hero-button-dark">
                <span>See the work</span>

                <span className="hero-button-icon">
                  <svg viewBox="0 0 18 18" aria-hidden="true">
                    <path d="M3 9h11" />
                    <path d="m9 3 6 6-6 6" />
                  </svg>
                </span>
              </a>

              <a
                href="#contact"
                className="hero-button hero-button-light"
              >
                <span>Start a project</span>

                <span className="hero-button-icon">
                  <svg viewBox="0 0 18 18" aria-hidden="true">
                    <path d="M4 5.5A3.5 3.5 0 0 1 7.5 2h3A3.5 3.5 0 0 1 14 5.5v3A3.5 3.5 0 0 1 10.5 12H9l-3.5 3v-3.4A3.5 3.5 0 0 1 4 8.5v-3Z" />
                  </svg>
                </span>
              </a>
            </div>
          </div>
        </div>

        <div className="hero-bottom">
          <span className="hero-bottom-label">Scroll to explore</span>

          <span className="hero-scroll-arrow">
            ↓
          </span>
        </div>
      </div>
    </section>
  );
};

export default Hero;