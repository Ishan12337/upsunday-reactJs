import React from 'react';

function AwardCard({ title, colorClass }) {
  return (
    <li className="flex w-[62vw] max-w-[300px] shrink-0 snap-start flex-col gap-4 sm:w-[38vw] lg:w-auto lg:max-w-none">
      <div className={`relative aspect-[724/1024] overflow-hidden rounded-[16px] shadow-[0_1px_0_rgba(12,16,22,0.04)] ${colorClass} flex items-center justify-center`}>
         {/* Placeholder for award poster */}
         <div className="text-white font-display font-bold text-center px-4 opacity-50 text-xl">{title}</div>
      </div>
      <p className="text-[16px] leading-[1.4] font-medium text-ink-2 lg:text-[17px]">
        {title}
      </p>
    </li>
  );
}

function Recognition() {
  return (
    <section className="flex flex-col gap-stack py-16 lg:py-20">
      <div className="flex flex-col gap-header gutter">
        <p className="text-kicker text-[#8d949c]">Recognition</p>
        <h2 className="text-statement max-w-[1416px] text-ink-2">
          Work the design world <em className="text-orange not-italic">noticed</em>
        </h2>
      </div>
      
      <ul className="gutter flex snap-x snap-mandatory scroll-px-[max(1.25rem,5vw)] gap-4 overflow-x-auto overscroll-x-contain pb-8 lg:grid lg:grid-cols-5 lg:overflow-visible [&::-webkit-scrollbar]:hidden" style={{scrollbarWidth: 'none'}}>
        <AwardCard title="Awwwards Honors" colorClass="bg-zinc-800" />
        <AwardCard title="CSSDA Best UI" colorClass="bg-zinc-700" />
        <AwardCard title="CSSDA Best UX" colorClass="bg-zinc-800" />
        <AwardCard title="CSSDA Best Innovation" colorClass="bg-zinc-700" />
        <AwardCard title="CSSDA Special Kudos" colorClass="bg-zinc-800" />
      </ul>
    </section>
  );
}

export default Recognition;