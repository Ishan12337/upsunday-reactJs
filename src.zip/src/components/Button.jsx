import React from 'react';
import { ArrowRight, MessageCircle } from 'lucide-react';

export function Button({ 
  children, 
  href, 
  variant = 'dark', // 'dark', 'light', 'stone'
  icon = 'arrow', // 'arrow', 'chat', 'none'
  className = '',
  onClick
}) {
  const isLink = !!href;
  const Component = isLink ? 'a' : 'button';
  
  const baseClasses = "group inline-flex items-center gap-[22px] rounded-full py-[6px] pr-[6px] pl-[26px] lg:pl-[34px] outline-none outline-offset-4 transition-all duration-300";
  
  const variants = {
    dark: "bg-[#161b21] text-white hover:bg-[#252c35]",
    light: "bg-white text-[#161b21] hover:bg-gray-100",
    stone: "bg-[#e8e4db] text-[#161b21] hover:bg-[#dfdad0]"
  };

  const iconBgVariants = {
    dark: "bg-[#252c35] text-white",
    light: "bg-[#e8e4db] text-[#161b21]",
    stone: "bg-[#dfdad0] text-[#161b21]"
  };

  const renderIcon = () => {
    if (icon === 'arrow') return <ArrowRight size={18} strokeWidth={2} />;
    if (icon === 'chat') return <MessageCircle size={18} strokeWidth={2} />;
    return null;
  };

  return (
    <Component 
      href={href} 
      className={`${baseClasses} ${variants[variant]} ${className}`}
      onClick={onClick}
    >
      <span className="relative block overflow-hidden text-[15px] leading-[1.4] font-medium uppercase whitespace-nowrap lg:text-[17px]">
        <span className="block transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:-translate-y-full group-focus-visible:-translate-y-full">
          {children}
        </span>
        <span aria-hidden="true" className="absolute inset-0 block translate-y-full transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:translate-y-0 group-focus-visible:translate-y-0">
          {children}
        </span>
      </span>
      {icon !== 'none' && (
        <span className={`flex size-11 shrink-0 items-center justify-center overflow-hidden rounded-full lg:size-12 transition-colors duration-300 ${iconBgVariants[variant]}`}>
          <span className="transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:translate-x-1 group-focus-visible:translate-x-1">
            {renderIcon()}
          </span>
        </span>
      )}
    </Component>
  );
}
