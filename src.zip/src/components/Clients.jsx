import React from 'react';

function Clients() {
  return (
    <section className="py-10 lg:py-14">
      <div className="gutter group/row hidden items-center justify-between xl:flex">
        <p className="text-[16px] leading-[1.3] font-medium text-mute">
          Trusted by founders<br/>and growing brands
        </p>
        <div className="flex items-center gap-14">
          <div className="text-xl font-bold text-gray-400 hover:text-ink-2 transition-colors cursor-pointer">Bad Birdie</div>
          <div className="text-xl font-bold text-gray-400 hover:text-ink-2 transition-colors cursor-pointer">Milk &amp; Cookies</div>
          <div className="text-xl font-bold text-gray-400 hover:text-ink-2 transition-colors cursor-pointer">COBE Construction</div>
          <div className="text-xl font-bold text-gray-400 hover:text-ink-2 transition-colors cursor-pointer">Left Coast</div>
        </div>
      </div>
      
      <div className="xl:hidden">
        <p className="gutter mb-6 text-[15px] leading-[1.3] font-medium text-mute">
          Trusted by founders and growing brands
        </p>
        <div className="overflow-hidden flex whitespace-nowrap mask-image-gradient">
          <div className="flex items-center gap-14 pr-14 sm:gap-20 sm:pr-20 animate-marquee">
            <div className="text-xl font-bold text-gray-400">Bad Birdie</div>
            <div className="text-xl font-bold text-gray-400">Milk &amp; Cookies</div>
            <div className="text-xl font-bold text-gray-400">COBE Construction</div>
            <div className="text-xl font-bold text-gray-400">Left Coast</div>
          </div>
          <div className="flex items-center gap-14 pr-14 sm:gap-20 sm:pr-20 animate-marquee" aria-hidden="true">
            <div className="text-xl font-bold text-gray-400">Bad Birdie</div>
            <div className="text-xl font-bold text-gray-400">Milk &amp; Cookies</div>
            <div className="text-xl font-bold text-gray-400">COBE Construction</div>
            <div className="text-xl font-bold text-gray-400">Left Coast</div>
          </div>
        </div>
      </div>
      <style>{`
        @keyframes marquee {
          from { transform: translateX(0); }
          to { transform: translateX(-100%); }
        }
        .animate-marquee {
          animation: marquee 20s linear infinite;
        }
        .mask-image-gradient {
          mask-image: linear-gradient(90deg, transparent, #000 12%, #000 88%, transparent);
          -webkit-mask-image: linear-gradient(90deg, transparent, #000 12%, #000 88%, transparent);
        }
      `}</style>
    </section>
  );
}

export default Clients;