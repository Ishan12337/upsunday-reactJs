import React from "react";
import "./styling/SelectedWork.css";

import cover1 from "../assets/work/cover-1.jpg";
import cover2 from "../assets/work/cover-2.jpg";

function WorkCard({ title, image, tags }) {
  return (
    <article className="work-card">
      <a href="/work" className="work-card-link">
        <div className="work-image">
          <img src={image} alt={`${title} project preview`} />
        </div>

        <div className="work-info">
          <h3>{title}</h3>

          <div className="work-tags">
            {tags.map((tag) => (
              <span key={tag}>{tag}</span>
            ))}
          </div>
        </div>
      </a>
    </article>
  );
}

function SelectedWork() {
  return (
    <section id="work" className="selected-work">
      <div className="selected-work-header">
        <h2>Selected work</h2>

        <a href="/work" className="all-work-link">
          All work
        </a>
      </div>

      <div className="selected-work-grid">
        <WorkCard
          title="Milk and Cookies"
          image={cover1}
          tags={["Brand", "Web"]}
        />

        <WorkCard
          title="Left Coast Design Studio"
          image={cover2}
          tags={["Web"]}
        />
      </div>
    </section>
  );
}

export default SelectedWork;