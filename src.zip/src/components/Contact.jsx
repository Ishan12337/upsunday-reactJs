import React from 'react';
import { Button } from './Button';

function Contact() {
  return (
    <section className="px-2 pb-2 sm:px-3 lg:px-6 lg:pb-6">
      <div className="flex flex-col items-center justify-center gap-8 rounded-[24px] bg-[#252c35] px-5 py-24 text-center sm:px-10 lg:rounded-[32px] lg:px-[72px] lg:py-32 relative overflow-hidden">
        {/* Subtle decorative background */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#323b46]/20 to-transparent"></div>
        
        <div className="relative z-10 flex flex-col items-center gap-6 max-w-3xl">
          <h2 className="text-[clamp(40px,6vw,80px)] leading-[1.05] font-display font-medium tracking-[-0.02em] text-white">
            Let's build something <em className="text-orange not-italic">great</em> together.
          </h2>
          <p className="text-[17px] leading-[1.5] text-[#9aa1a9] lg:text-[20px] max-w-xl">
            Whether you need a new brand, a custom website, or complex software, our team is ready to help you grow.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 mt-4">
            <Button href="/contact" variant="light" icon="arrow">
              Start a project
            </Button>
            <Button href="mailto:hello@upsunday.co" variant="stone" icon="none">
              hello@upsunday.co
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Contact;