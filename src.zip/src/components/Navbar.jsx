import { useEffect, useState } from "react";
import "./styling/Navbar.css";

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";

    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <>
      <header className={`navbar ${scrolled ? "navbar-scrolled" : ""}`}>
        <a href="#home" className="navbar-logo-link" aria-label="UpSunday home">
          <span className="navbar-logo">
            <img
              src="https://upsunday.co/brand/logo-dark.svg"
              alt="upsunday"
              className="logo-dark"
            />

            <img
              src="https://upsunday.co/brand/logo-light.svg"
              alt=""
              aria-hidden="true"
              className="logo-light"
            />
          </span>
        </a>

        <nav className="navbar-actions" aria-label="Primary">
          {/* CHAT */}
          <a href="#contact" className="navbar-pill navbar-chat">
            <span className="label-mask">
              <span className="label-track">
                <span className="label-primary">Chat with us</span>
                <span className="label-secondary">Chat with us</span>
              </span>
            </span>

            <span className="navbar-icon chat-icon">
              <svg
                viewBox="0 0 24 24"
                aria-hidden="true"
                focusable="false"
              >
                <path
                  d="M8.5 18H7a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v6a4 4 0 0 1-4 4h-4.2l-4.3 3v-3Z"
                />
              </svg>
            </span>
          </a>

          {/* MENU */}
          <button
            type="button"
            className="navbar-pill navbar-menu-button"
            onClick={() => setMenuOpen(true)}
            aria-label="Open menu"
            aria-expanded={menuOpen}
          >
            <span className="label-mask">
              <span className="label-track">
                <span className="label-primary">Menu</span>
                <span className="label-secondary">Menu</span>
              </span>
            </span>

            <span className="navbar-icon menu-icon">
              <svg
                viewBox="0 0 16 6"
                aria-hidden="true"
                focusable="false"
              >
                <circle cx="4" cy="3" r="2.4" />
                <circle cx="12" cy="3" r="2.4" />
              </svg>
            </span>
          </button>
        </nav>
      </header>

      {/* FULL SCREEN MENU */}
      <div
        className={`menu-overlay ${menuOpen ? "menu-open" : ""}`}
        aria-hidden={!menuOpen}
      >
        <div className="menu-overlay-inner">
          <div className="menu-top">
            <span className="menu-title">Menu</span>

            <button
              type="button"
              className="navbar-pill menu-close-button"
              onClick={closeMenu}
              aria-label="Close menu"
            >
              <span className="label-mask">
                <span className="label-track">
                  <span className="label-primary">Close</span>
                  <span className="label-secondary">Close</span>
                </span>
              </span>

              <span className="navbar-icon close-icon">
                <span></span>
                <span></span>
              </span>
            </button>
          </div>

          <nav className="menu-links" aria-label="Menu">
            <a href="#home" onClick={closeMenu}>
              Home
            </a>

            <a href="#services" onClick={closeMenu}>
              Services
            </a>

            <a href="#work" onClick={closeMenu}>
              Work
            </a>

            <a href="#about" onClick={closeMenu}>
              About
            </a>

            <a href="#blog" onClick={closeMenu}>
              Blog
            </a>

            <a href="#contact" onClick={closeMenu}>
              Contact
            </a>
          </nav>
        </div>
      </div>
    </>
  );
};

export default Navbar;