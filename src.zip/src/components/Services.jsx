import React from 'react';
import { ArrowRight } from 'lucide-react';

function ServiceCard({ title, description, tags, colorClass }) {
  return (
    <a href="#" className="group flex h-full flex-col gap-7 rounded-[28px] bg-[#323b46] p-4 outline-none hover:bg-[#28303a] transition-colors duration-300">
      <div className={`relative h-[240px] overflow-hidden rounded-[18px] sm:h-[300px] ${colorClass} flex items-center justify-center`}>
        {/* Placeholder for service illustration */}
        <div className="absolute inset-0 bg-[#f3f0eb]/10 transition-opacity duration-700"></div>
      </div>
      <div className="flex flex-col gap-3 px-4 pb-4">
        <div className="flex items-center justify-between gap-4">
          <h3 className="text-[32px] leading-[1.4] font-medium tracking-[-0.01em] text-white transition-transform duration-500 group-hover:translate-x-1.5 lg:text-[40px]">
            {title}
          </h3>
          <span aria-hidden="true" className="flex size-11 shrink-0 -translate-x-3 items-center justify-center rounded-full bg-white text-ink-2 opacity-0 transition-all duration-500 group-hover:translate-x-0 group-hover:opacity-100">
            <ArrowRight size={18} strokeWidth={2} />
          </span>
        </div>
        <p className="text-[17px] leading-[1.4] text-[#9aa1a9] lg:text-[18px]">
          {description}
        </p>
        <div className="flex flex-wrap gap-2 pt-3">
          {tags.map(tag => (
            <span key={tag} className="inline-flex rounded-full px-4 py-2 text-[14px] leading-[1.4] font-medium whitespace-nowrap lg:text-[15px] bg-[#434c56] text-[#d5d9de]">
              {tag}
            </span>
          ))}
        </div>
      </div>
    </a>
  );
}

function Services() {
  return (
    <section className="gutter flex flex-col gap-stack bg-[#252c35] py-16 lg:py-24">
      <div className="flex flex-col gap-header">
        <p className="text-kicker text-[#7d848c]">Services</p>
        <h2 className="text-statement max-w-[1416px] text-white">
          Everything your brand needs, built by <em className="text-orange not-italic">one</em> team
        </h2>
      </div>
      
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <ServiceCard 
          title="Brand" 
          description="Identities people know at a glance and remember long after." 
          tags={['Identity', 'Logo systems', 'Guidelines']} 
          colorClass="bg-rose-900/40"
        />
        <ServiceCard 
          title="Web" 
          description="Websites that load fast, look sharp and turn visitors into clients." 
          tags={['UI/UX', 'Development', 'CMS']} 
          colorClass="bg-blue-900/40"
        />
        <ServiceCard 
          title="Software" 
          description="Custom apps, portals and AI features that run the business behind the brand." 
          tags={['Web apps', 'Dashboards', 'AI features']} 
          colorClass="bg-emerald-900/40"
        />
        <ServiceCard 
          title="Motion" 
          description="Movement and 3D that make your brand impossible to scroll past." 
          tags={['3D', 'Animation', 'Interaction']} 
          colorClass="bg-purple-900/40"
        />
      </div>
    </section>
  );
}

export default Services;