import React from 'react';

function Footer() {
  return (
    <footer className="bg-[#161b21] text-white pt-20 pb-10">
      <div className="gutter flex flex-col gap-16">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-4 lg:gap-8">
          <div className="lg:col-span-2 flex flex-col gap-6">
            <span className="font-display text-3xl font-bold tracking-tight">UpSunday</span>
            <p className="max-w-sm text-[16px] leading-[1.5] text-[#9aa1a9]">
              A web design, branding and development studio working with companies worldwide.
            </p>
          </div>
          
          <div className="flex flex-col gap-4">
            <h4 className="text-[14px] font-medium uppercase tracking-wider text-[#9aa1a9]">Navigation</h4>
            <nav className="flex flex-col gap-3">
              <a href="/" className="text-[16px] hover:text-orange transition-colors">Home</a>
              <a href="/work" className="text-[16px] hover:text-orange transition-colors">Work</a>
              <a href="/services" className="text-[16px] hover:text-orange transition-colors">Services</a>
              <a href="/about" className="text-[16px] hover:text-orange transition-colors">About</a>
              <a href="/contact" className="text-[16px] hover:text-orange transition-colors">Contact</a>
            </nav>
          </div>
          
          <div className="flex flex-col gap-4">
            <h4 className="text-[14px] font-medium uppercase tracking-wider text-[#9aa1a9]">Socials</h4>
            <nav className="flex flex-col gap-3">
              <a href="#" className="text-[16px] hover:text-orange transition-colors">Instagram</a>
              <a href="#" className="text-[16px] hover:text-orange transition-colors">LinkedIn</a>
              <a href="#" className="text-[16px] hover:text-orange transition-colors">Twitter (X)</a>
              <a href="#" className="text-[16px] hover:text-orange transition-colors">Dribbble</a>
            </nav>
          </div>
        </div>
        
        <div className="flex flex-col items-center justify-between gap-6 border-t border-white/10 pt-8 sm:flex-row text-[14px] text-[#9aa1a9]">
          <p>© {new Date().getFullYear()} UpSunday LLC. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
