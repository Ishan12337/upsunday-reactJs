import React from 'react';
import { ArrowRight } from 'lucide-react';

function BlogPostCard({ title, category, readTime, colorClass }) {
  return (
    <a href="#" className="group flex flex-col gap-4 rounded-[20px] outline-none lg:gap-5">
      <div className={`relative aspect-[450/260] overflow-hidden rounded-[20px] ${colorClass} flex items-center justify-center`}>
        {/* Placeholder image for blog post */}
        <div className="text-white opacity-40 font-display font-medium text-xl">{category}</div>
        <div className="absolute inset-0 transition-transform duration-[1.2s] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.03] -z-10 bg-current opacity-50"></div>
      </div>
      <div className="flex flex-col gap-3">
        <div className="flex items-center gap-3 text-[14px] font-medium text-[#8d949c]">
          <span className="rounded-full border border-gray-200 bg-white px-3 py-1 text-ink-2">{category}</span>
          <span>{readTime}</span>
        </div>
        <div className="flex items-start justify-between gap-4">
          <h3 className="text-[22px] leading-[1.3] font-medium tracking-[-0.01em] text-ink-2 lg:text-[26px]">
            {title}
          </h3>
          <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-[#f6f4f1] text-ink transition-transform duration-300 group-hover:bg-[#252c35] group-hover:text-white">
            <ArrowRight size={16} strokeWidth={2} className="transition-transform duration-300 group-hover:-rotate-45" />
          </span>
        </div>
      </div>
    </a>
  );
}

function Blog() {
  return (
    <section className="gutter flex flex-col gap-stack py-16 lg:py-24">
      <div className="flex flex-col gap-header">
        <p className="text-kicker text-[#8d949c]">Blog</p>
        <h2 className="text-statement max-w-[1416px] text-ink-2">
          Ideas on design, code and building brands that <em className="text-orange not-italic">last</em>
        </h2>
      </div>
      
      <div className="grid grid-cols-1 gap-x-4 gap-y-12 md:grid-cols-3">
        <BlogPostCard 
          title="Motion first web design"
          category="Design"
          readTime="5 min read"
          colorClass="bg-emerald-900"
        />
        <BlogPostCard 
          title="Why your brand needs a custom CMS"
          category="Development"
          readTime="4 min read"
          colorClass="bg-blue-900"
        />
        <BlogPostCard 
          title="The psychology behind perfect typography"
          category="Brand"
          readTime="6 min read"
          colorClass="bg-rose-900"
        />
      </div>
    </section>
  );
}

export default Blog;