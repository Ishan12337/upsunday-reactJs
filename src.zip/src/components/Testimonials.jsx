import React from 'react';

function TestimonialCard({ quote, author, role, company, bgColor1, bgColor2, textColor }) {
  return (
    <li 
      className="group relative isolate flex min-h-[540px] w-[82vw] max-w-[400px] shrink-0 snap-start flex-col overflow-hidden rounded-[24px] px-7 pt-[220px] pb-7 lg:pt-[250px] md:w-auto md:max-w-none lg:min-h-[600px] lg:px-8 lg:pb-8"
      style={{ backgroundImage: `linear-gradient(180deg, ${bgColor1} 0%, ${bgColor2} 62%)` }}
    >
      <div aria-hidden="true" className="absolute inset-x-0 bottom-0 -z-10 h-[68%]" style={{ backgroundImage: `linear-gradient(0deg, ${bgColor2} 55%, transparent)` }}></div>
      
      <figure className={`flex flex-1 flex-col gap-6 ${textColor}`}>
        <div className="flex h-9 items-end lg:h-10">
          <div className="text-xl font-display font-bold">{company}</div>
        </div>
        <blockquote className="text-[18px] leading-[1.42] tracking-[-0.01em] lg:text-[19px]">
          “{quote}”
        </blockquote>
        <figcaption className="mt-auto flex items-center gap-3 border-t pt-5 border-current/10">
          <div className="size-11 shrink-0 rounded-full bg-current/20"></div>
          <div className="flex flex-col leading-[1.35]">
            <span className="text-[16px] font-medium">{author}</span>
            <span className="text-[14px] opacity-70">{role}</span>
          </div>
        </figcaption>
      </figure>
    </li>
  );
}

function Testimonials() {
  return (
    <section className="flex flex-col gap-stack bg-[#f7f4ef] py-16 lg:py-24">
      <div className="flex flex-col gap-header gutter">
        <p className="text-kicker text-[#8d949c]">Testimonials</p>
        <h2 className="text-statement max-w-[1416px] text-ink-2">
          Straight from the <em className="text-orange not-italic">founders</em> we build for
        </h2>
      </div>
      
      <ul className="gutter flex snap-x snap-mandatory scroll-px-[max(1.25rem,5vw)] gap-4 overflow-x-auto overscroll-x-contain pb-8 md:grid md:grid-cols-2 md:overflow-visible xl:grid-cols-4 [&::-webkit-scrollbar]:hidden" style={{scrollbarWidth: 'none'}}>
        <TestimonialCard 
          company="Left Coast Design Studio"
          quote="As a design studio, we're hard to impress. UpSunday matched the craft of our own work: clean lines, perfect proportions, and nothing on the page that doesn't need to be there."
          author="Craig Trettau"
          role="Founder"
          bgColor1="#e9e0d3"
          bgColor2="#f7f4ef"
          textColor="text-[#161b21]"
        />
        <TestimonialCard 
          company="COBE Construction Inc."
          quote="UpSunday gave COBE a look that finally matches the quality of our builds. Clean, confident and built to last, just like our work."
          author="Shaun Olson"
          role="President"
          bgColor1="#dcebf7"
          bgColor2="#f9f9f9"
          textColor="text-[#161b21]"
        />
        <TestimonialCard 
          company="Milk & Cookies"
          quote="UpSunday gave our brand a shape it never had before. Every page feels considered, the type, the spacing, the way it moves. It looks like us, just sharper."
          author="Chasen McNaughton"
          role="Co-Founder"
          bgColor1="#1a1a1a"
          bgColor2="#000000"
          textColor="text-white"
        />
        <TestimonialCard 
          company="Bad Birdie"
          quote="The design has a shape and rhythm you feel as soon as the page loads. UpSunday took our ideas and made them look inevitable."
          author="Tanner Balisky"
          role="Founder"
          bgColor1="#f1f1f1"
          bgColor2="#ffffff"
          textColor="text-[#161b21]"
        />
      </ul>
    </section>
  );
}

export default Testimonials;