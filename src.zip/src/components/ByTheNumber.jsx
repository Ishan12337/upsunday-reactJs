import React from 'react';

function StatCard({ number, description }) {
  return (
    <div className="flex flex-col justify-between gap-12 rounded-[24px] bg-white p-7 lg:gap-20 lg:p-10 shadow-sm">
      <p className="text-[clamp(88px,9.26vw,160px)] leading-none font-medium tracking-[-0.05em] text-[#161b21]">
        {number}
      </p>
      <p className="max-w-[300px] text-[17px] leading-[1.4] text-[#8d949c] lg:text-[20px]">
        {description}
      </p>
    </div>
  );
}

function ByTheNumber() {
  return (
    <section className="gutter flex flex-col gap-stack py-16 lg:py-20">
      <div className="flex flex-col gap-header">
        <p className="text-kicker text-[#8d949c]">By the numbers</p>
        <h2 className="text-statement max-w-[1416px] text-ink-2">
          Work that <em className="text-orange not-italic">performs</em> as well as it looks
        </h2>
      </div>
      
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <StatCard 
          number="40+" 
          description="Projects designed, built and launched." 
        />
        <StatCard 
          number="12+" 
          description="Awards from Awwwards and CSS Design Awards." 
        />
        <StatCard 
          number="10M+" 
          description="Monthly views across the sites we've built." 
        />
      </div>
    </section>
  );
}

export default ByTheNumber;